<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 14px; direction: rtl; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: right; }
        h2 { margin-bottom: 0; }
        .total { font-weight: bold; font-size: 16px; margin-top: 20px; }
    </style>
</head>
<body>
    <h2>فاکتور فروش</h2>
    <p>شماره فاکتور: <span dir="ltr" style="unicode-bidi: embed;"><?php echo e($invoice->invoice_number); ?></span></p>
    <p>تاریخ: <span dir="ltr" style="unicode-bidi: embed;"><?php echo e(\App\Support\Jalali::fromCarbon($invoice->created_at, true)); ?></span></p>
    <p>کافه: <?php echo e($order->cafe->name); ?></p>

    <table>
        <thead>
            <tr>
                <th>محصول</th>
                <th>تعداد</th>
                <th>قیمت واحد</th>
                <th>جمع</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format($item->unit_price)); ?></td>
                    <td><?php echo e(number_format($item->unit_price * $item->quantity)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php
        // تفکیک تخفیف و مالیات فقط برای نمایش؛ از روی اقلام سفارش محاسبه می‌شود و چیزی در دیتابیس ذخیره نمی‌شود
        $ratio = (float) $order->discount_percentage / 100;
        $subtotal = 0;
        $discount = 0;
        foreach ($order->items as $item) {
            $line = $item->unit_price * $item->quantity;
            $subtotal += $line;
            if ($item->product && $item->product->is_discountable) {
                $discount += $line * $ratio;
            }
        }
        $subtotal = round($subtotal, 2);
        $discount = round($discount, 2);
        $afterDiscount = $subtotal - $discount;
        // مالیات = مبلغ نهایی ثبت‌شده منهای مبلغ بعد از تخفیف، تا فاکتور همیشه دقیقاً جمع بزند
        $tax = round((float) $order->total_amount - $afterDiscount, 2);
    ?>

    <table style="width: 60%; margin-right: 0; margin-left: auto;">
        <tr>
            <td>جمع اقلام</td>
            <td><?php echo e(number_format($subtotal)); ?> تومان</td>
        </tr>
        <?php if($discount > 0): ?>
            <tr>
                <td>تخفیف (<?php echo e((float) $order->discount_percentage); ?>٪<?php if($order->discountCode): ?> - <?php echo e($order->discountCode->code); ?><?php endif; ?>)</td>
                <td>- <?php echo e(number_format($discount)); ?> تومان</td>
            </tr>
            <tr>
                <td>مبلغ پس از تخفیف</td>
                <td><?php echo e(number_format($afterDiscount)); ?> تومان</td>
            </tr>
        <?php endif; ?>
        <?php if($tax > 0): ?>
            <tr>
                <td>مالیات (<?php echo e((float) $order->tax_percentage); ?>٪)</td>
                <td>+ <?php echo e(number_format($tax)); ?> تومان</td>
            </tr>
        <?php endif; ?>
        <tr>
            <td style="font-weight: bold; font-size: 16px;">مبلغ نهایی</td>
            <td style="font-weight: bold; font-size: 16px;"><?php echo e(number_format($order->total_amount)); ?> تومان</td>
        </tr>
    </table>
</body>
</html><?php /**PATH /home/ali/Desktop/projects/qahvehchiyan/resources/views/invoices/template.blade.php ENDPATH**/ ?>