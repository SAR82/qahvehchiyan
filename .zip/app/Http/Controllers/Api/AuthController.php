<?php

namespace App\Http\Controllers\Api;


use App\Models\Cafe;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use App\Services\OtpService;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'phone' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);
    
        $user = User::where('phone', $credentials['phone'])->first();
    
        if ($user && $user->role === 'owner') {
            throw ValidationException::withMessages([
                'phone' => ['مالکان کافه باید با کد پیامکی وارد شوند.'],
            ]);
        }
    
        if (! $user || ! Auth::attempt($credentials)) {
            throw ValidationException::withMessages([
                'phone' => ['شماره تلفن یا رمز عبور اشتباه است.'],
            ]);
        }
    
        if (! $user->is_active) {
            throw ValidationException::withMessages([
                'phone' => ['حساب کاربری غیرفعال است.'],
            ]);
        }
    
        $token = $user->createToken('auth_token')->plainTextToken;
    
        return response()->json([
            'user' => $user,
            'token' => $token,
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'خارج شدید.']);
    }

    public function me(Request $request)
    {
        return response()->json($request->user()->load('cafe'));
    }

    public function requestRegisterOtp(Request $request, OtpService $otpService)
    {
        $data = $request->validate(
            ['phone' => ['required', 'string', 'regex:/^09\d{9}$/', 'unique:users,phone']],
            [
                'phone.unique' => 'این شماره قبلاً ثبت شده است؛ از صفحه‌ی ورود وارد شوید.',
                'phone.regex'  => 'شماره تلفن باید به‌صورت 09123456789 باشد.',
            ]
        );

        if ($otpService->isLocked($data['phone'], 'cafe_register')) {
            return response()->json(['message' => 'تلاش‌های زیاد است. بعداً دوباره امتحان کنید.'], 429);
        }

        $otpService->requestCode($data['phone'], 'cafe_register');

        return response()->json(['message' => 'کد تأیید ارسال شد.']);
    }

    public function register(Request $request, OtpService $otpService)
    {
        $data = $request->validate(
            [
                'cafe_name' => ['required', 'string', 'max:255'],
                'phone' => ['required', 'string', 'regex:/^09\d{9}$/', 'unique:users,phone'],
                'code' => ['required', 'string'],
            ],
            ['phone.unique' => 'این شماره قبلاً ثبت شده است؛ از صفحه‌ی ورود وارد شوید.',
              'phone.regex'  => 'شماره تلفن باید به‌صورت 09123456789 باشد.',]
        );

        if ($otpService->isLocked($data['phone'], 'cafe_register')) {
            return response()->json(['message' => 'تلاش‌های ناموفق زیاد است. بعداً دوباره امتحان کنید.'], 429);
        }

        if (! $otpService->verifyCode($data['phone'], $data['code'], 'cafe_register')) {
            return response()->json(['message' => 'کد وارد شده نامعتبر یا منقضی شده است.'], 422);
        }

        $owner = DB::transaction(function () use ($data) {
            $cafe = Cafe::create(['name' => $data['cafe_name'], 'status' => 'pending']);

            $owner = User::create([
                'cafe_id' => $cafe->id,
                'phone' => $data['phone'],
                'password' => bcrypt(Str::random(40)), // مالک فقط با کد پیامکی وارد می‌شود
                'role' => 'owner',
            ]);

            $cafe->owner_id = $owner->id;
            $cafe->save();

            return $owner;
        });

        return response()->json([
            'message' => 'ثبت‌نام با موفقیت انجام شد. کافه شما در انتظار تایید مدیریت است.',
            'user' => $owner,
            'token' => $owner->createToken('auth_token')->plainTextToken,
        ], 201);
    }

    public function requestOtp(Request $request, OtpService $otpService)
    {
        $data = $request->validate([
            'phone' => ['required', 'string'],
        ]);

        $owner = User::where('phone', $data['phone'])
            ->where('role', 'owner')
            ->where('is_active', true)
            ->first();

        if ($owner && ! $otpService->isLocked($data['phone'], 'cafe_owner')) {
            $otpService->requestCode($data['phone'], 'cafe_owner');
        }

        // پاسخ همیشه یکسان است، چه شماره باشد چه نباشد
        return response()->json(['message' => 'اگر این شماره ثبت شده باشد، کد ارسال شد.']);
    }

    public function verifyOtp(Request $request, OtpService $otpService)
    {
        $data = $request->validate([
            'phone' => ['required', 'string'],
            'code' => ['required', 'string'],
        ]);

        if ($otpService->isLocked($data['phone'], 'cafe_owner')) {
            return response()->json(['message' => 'تلاش‌های ناموفق زیاد است. بعداً دوباره امتحان کنید.'], 429);
        }

        if (! $otpService->verifyCode($data['phone'], $data['code'], 'cafe_owner')) {
            return response()->json(['message' => 'کد وارد شده نامعتبر یا منقضی شده است.'], 422);
        }

        $owner = User::where('phone', $data['phone'])
            ->where('role', 'owner')
            ->where('is_active', true)
            ->first();

        if (! $owner) {
            return response()->json(['message' => 'کد وارد شده نامعتبر یا منقضی شده است.'], 422);
        }

        $token = $owner->createToken('otp_login')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $owner,
        ]);
    }
}